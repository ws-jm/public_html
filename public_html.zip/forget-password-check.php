<?php
    header("Location: https://adm-gui.sarus.com/forget_password_check.php");
//    require_once('/home/marketdata/www/forget_password_check.php');
?>