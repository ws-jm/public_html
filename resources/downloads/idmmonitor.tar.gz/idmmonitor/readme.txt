To install a package from a .tar.gz file, follow these steps:

    Launch R to have the R command prompt
    Type: install.packages(<path_to_tar.gz_file>, repos = NULL)
    Exampel: install.packages("idmmonitor_0.2.0.tar.gz", repos = NULL)

or launch directly:

R CMD INSTALL <path_to_.tar.gz_file>
