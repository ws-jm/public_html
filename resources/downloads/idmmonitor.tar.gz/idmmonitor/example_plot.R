library(idmmonitor)
library(highcharter)
library(tidyverse)
library(lubridate)


# 1. First you must Register API key  in the package
idata.set_api_key("0NJZF-HA1PI-C36TX-GSV2U")

# Note use get_datasets  to retrieve all Symbols of one Datasource for example ECBFX
idata.get_datasets(Datasource = "ECBFX")$Result$Datasets$Symbol

#2. Get the data using  the Monitor+ API      ---------------------
# for  EURNZD --------
Result_EURNZD = idata.get_dataset_values(Series  ="ECBFX/EURNZD",StartDate = "2010-01-01")$Result
values_EURNZD = unlist(Result_EURNZD$Series$Values)

# for  EURUSD --------
Result_EURUSD = idata.get_dataset_values(Series  ="ECBFX/EURUSD",StartDate = "2010-01-01")$Result
values_EURUSD = unlist(Result_EURUSD$Series$Values)
# save the results as Dataframe
aux_EURNZD  = data.frame(date=as.Date(names(values_EURNZD)),
                         value=as.numeric(values_EURNZD))


aux_EURUSD  = data.frame(date=as.Date(names(values_EURUSD)),
                         value=as.numeric(values_EURUSD))


# group by weekly
aux_EURNZD_weekly = aux_EURNZD %>% group_by(date = cut(date, "week")) %>% summarise(value = mean(value))
aux_EURUSD_weekly = aux_EURUSD %>% group_by(date = cut(date, "week")) %>% summarise(value = mean(value))



#3. simple plot ----------------------------------------------
plot(aux_EURNZD$date,aux_EURNZD$value,xlab= "Date",ylab = "EURNZD",col="red",ylim = c(0.5,2.5),pch = 1)
points(aux_EURUSD$date,aux_EURUSD$value,xlab= "Date",ylab = "EURUSD",col="green",pch=3)
# Plot legend where you want
legend("topright", inset=c(0,-0.1), legend=c("EURNZD", "EURUSD"), pch=c(1,3), title="")

#4. iterative plot ----------------------
# per day
highchart() %>%
  hc_title(text = "ECBFX/EURNZD & ECBFX/EURUSD",useHTML=TRUE) %>%
  hc_chart(style=list(fontFamily="Trebuchet MS"), zoomType = "xy") %>%
  hc_legend(enabled = TRUE) %>%
  hc_xAxis(categories = format(aux_EURNZD$date,format="%d/%m/%Y"),
           labels=list(rotation=-90)) %>%
  hc_yAxis( title = list(text = "ok2",useHTML=TRUE),
            align = "right",
            showFirstLabel = FALSE,
            showLastLabel = FALSE,
            labels = list(format = "{value}", useHTML = TRUE),
            gridLineWidth= 0,
            allowDecimals=FALSE,
            reversed=FALSE,
            endOnTick = FALSE
  ) %>%
  hc_add_series(name ="EURNZD" , type = "spline",
                data =aux_EURNZD$value,
                cursor = "pointer",
                color = "blue",
                lineWidth = 2,
                marker = list(enabled = FALSE))  %>%
  hc_add_series(name = "EURUSD", type="spline",
                data=aux_EURUSD$value,
                cursor="pointer",
                color="red",
                lineWidth=2,
                marker = list(enabled = FALSE))







# group by week

highchart() %>%
  hc_title(text = "ECBFX/EURNZD & ECBFX/EURUSD (weekly)",useHTML=TRUE) %>%
  hc_chart(style=list(fontFamily="Trebuchet MS"), zoomType = "xy") %>%
  hc_legend(enabled = TRUE) %>%
  hc_xAxis(categories = format(aux_EURNZD_weekly$date,format="%d/%m/%Y"),
           labels=list(rotation=-90)) %>%
  hc_yAxis( title = list(text = "ok2",useHTML=TRUE),
            align = "right",
            showFirstLabel = FALSE,
            showLastLabel = FALSE,
            labels = list(format = "{value}", useHTML = TRUE),
            gridLineWidth= 0,
            allowDecimals=FALSE,
            reversed=FALSE,
            endOnTick = FALSE
  ) %>%
  hc_add_series(name ="EURNZD" , type = "spline",
                data =aux_EURNZD_weekly$value,
                cursor = "pointer",
                color = "blue",
                lineWidth = 2,
                marker = list(enabled = FALSE))  %>%
  hc_add_series(name = "EURUSD", type="spline",
                data=aux_EURUSD_weekly$value,
                cursor="pointer",
                color="red",
                lineWidth=2,
                marker = list(enabled = FALSE))





