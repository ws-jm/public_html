library(idmmonitor)


# 1. First you must Register API key  in the package
# idata.set_api_key("0NJZF-HA1PI-C36TX-GSV2U")
# idata.set_api_key("AU49T-YSH36-X8G5L-CVWZF")
idata.set_api_key("ZCP1I-WGMOJ-XUL8A-DF54E")


# You can set VERBOSE to TRUE for mrore feedback from the package
idata.set_verbose(T)

# 2.1 Now we request a session token from the API
idata.get_session_token()

# 2.2 Restore a Session Token to full life.
# idata.renew_session_token()


# 2.3 Revoke a Session Token to make it invalid.
# idata.revoke_session_token()

# 2.4 Return information about a Session Token.
idata.query_session_token()

# 3 Datasources

# 3.1 Get the metadata for one datasource.
idata.get_datasource(Datasource = "ECBFX")

# 3.2 Return the metadata from all available datasources.
idata.get_all_datasources()$Result$Datasource

# 3.3.Return the metadata for all datasources that are accessible to the user.
idata.get_user_datasources()$Result$Datasource


# 4 Datasets
# 4.1.Get the metadata for dataset in a single datasource.
idata.get_datasets(Datasource = "ECBFX")
idata.get_datasets(Datasource = "ECBFX",
                   CaseSensitive = TRUE,
                   Rows= 100,
                   Page = 1,
                   ShortRecord = FALSE,
                   SortColumn = "Symbol,Description",
                   Filter = "ECB -Texas")

# 4.2.Get the metadata for selected datasets.
idata.get_selected_datasets(Series = "ECBFX/EURGBP")
idata.get_selected_datasets(Series = "ECBFX/EURGBP,ECBFX/EURUSD")


# 5.Favorites
# 5.1.Return the series count and last changed timestamp of the favorites list on the server.
idata.get_user_favorite_status()

# 5.2.Return the User Favorites Metadata
idata.get_user_favorites()

# 5.3.Add one or more datasets to the user favorites list.
idata.add_user_favorites(Series = 'ECBFX/EURHRK')

# 5.4.Remove one or more datasets from the user favorites list.
idata.remove_user_favorites(Series = 'ECBFX/EURHRK')

# 6.MarketData
# 6.1.Get historical time series values.
Result = idata.get_dataset_values(Series  ="ECBFX/EURNZD",FrequencyOptions = "StartDay=1;UseStartDate=false" )$Result
values = unlist(Result$Series$Values)
plot(x =as.Date(names(values)),as.numeric(values),xlab= "Date",ylab = "Index")


# 6.2.Get historical time series values formatted row by column
Result = idata.get_dataset_valuesRC(Series  ="ECBFX/EURNZD")$Result
values = unlist(Result$Rows)
plot(x =as.Date(names(values)),as.numeric(values),xlab= "Date",ylab = "Index")


# 6.3.Get dataset values for a single date.
idata.get_dataset_values_for_date(Series = "ECBFX/EURGBP;BateIndex=[0],ECBFX/EURUSD;BateIndex=[0]", Date = "2017-10-24")
idata.get_dataset_values_for_date(Series = "ECBFX/EURGBP", Date = "2017-10-24")


# 7. MyAccount
# 7.1.Return the user account details.
idata.get_my_account_details()

# 7.2.Request a new API Key.
idata.request_new_api_key()

# 7.3.Request a new account password.
idata.send_password_reset(Email = "example@example.com")

# 7.4 Reset the Account Password

# 8 Additional
# 8.1 Get the Version number for the current API
















