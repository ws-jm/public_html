#' Get Datasource
#'
#'@description
#' Return the metadata for one named datasource.
#'@details
#' For more information please visit :  \url{https://www.idatamedia.org/api-docs#getonedatasource}
#'@return json or list
#' @param Datasource Default "" The ID of the datasource. For example use "ECBFX" for the European Bank currency rates datasource.
#'
#' @param SessionToken Optional. Session token from the idata.get_session_token command.
#' If no token is provided then the current token will be used. You can see the current token by typing  \code{idata.print_session_token()}.
#' @param ReturnCategoryList Optional. Default TRUE Returns detailed category information (only if the datasource is a category datasource).
#' @param ReturnCategoryTree Optional. Default TRUE If true, returns a hierarchical data tree  of the data categories (if available). The tree is used to organise and present the datasets in logical groups.
#'  See the Details and DetailsDS tables below for more details.
#' @param ReturnAccess Optional. Default FALSE. Returns which datasources and data categories that the user can/cannot access
#' @param DateFormat Optional. Default "FALSE."YYYY-MM-DD" The date format to use in the request and the result.  See the ‘DateFormat Parameter‘ section in the link below for details.
#' @examples
#' idata.get_datasource(Datasource = "ECBFX")               #use the current token
#' idata.get_datasource(Datasource = "ECBFX")$Result$Name   #use the current token and return the name only in the result
#' @export

idata.get_datasource <- function(SessionToken = NULL,Datasource = "ECBFX",ReturnCategoryList = TRUE,ReturnCategoryTree=TRUE,ReturnAccess=FALSE,DateFormat='YYYY-MM-DD'){
  api$get_datasource(SessionToken = SessionToken, Datasource = Datasource,ReturnCategoryList = ReturnCategoryList,ReturnCategoryTree=ReturnCategoryTree,ReturnAccess=ReturnAccess,DateFormat=DateFormat)
}
