#' Displays the selected  API address  for the current session token
#'
#' @return text message
#'
#' @examples
#' idata.get_api_address()
#' @export

idata.get_api_address <- function(){
	api$get_api_address()

}
