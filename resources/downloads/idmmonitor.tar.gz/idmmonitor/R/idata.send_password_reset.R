#' Send Password Reset
#'@description
#' Request to reset your password using  using an email link  sent from the server.
#'@details
#'For more information please visit :  \url{https://www.idatamedia.org/api-docs#newapikeyemail}
#' @return json or list
#' @param Send the registered email address (see idata.get_my_account_details to locate the corect email address) Email. The password reset email will be sent to this address.
#' @examples
#' idata.send_password_reset(Email="example@example.com")
#' @export
idata.send_password_reset <- function(Email = NULL){
  api$send_password_reset(Email = Email)
}
