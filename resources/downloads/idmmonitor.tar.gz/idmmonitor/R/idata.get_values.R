#' Get Dataset Values
#'@description
#' Use your session token to retrieve market data for datasets in one or more datasource.
#'@details
#'For more information please visit :  \url{https://www.idatamedia.org/api-docs#getdatasetvalues}
#' @return json or list
#' @param SessionToken Optional. Session token from the idata.get_session_token command.
#' If no token is provided then the current token will be used. You can see the current token by typing  \code{idata.print_session_token()}.
#' @param Series A list of comma separated values containing data source, category and symbol and optional additional parameters such as Bateindex.  Click on the help link above for the optional parameter list.
#' The category parameter is only used if the datasource is a category datasource.
#' Example: \code{ECBFX/EURGBP;Bateindex=[0],ECBFX/EURUSD}.
#' Note that elements in the list are separated by the '\code{,}' character and the data source, category and symbol values joined with a '\code{/}' character. No spaces between the elements.
#' For more information, click on the link above.
#' @param StartDate Optional. The earliest date to return. ‘Earliest’ means use first available.   Format is: “YYYY-MM-DD”.
#' @param EndDate Optional. The latest Date to return. ‘Latest’ means  use last available.  Format is: “YYYY-MM-DD”.
#' @param Periods Optional. Can be used  instead of the StartDate/EndDate parameters to return the most recent number of values in the selected frequency.
#' @param CommonStart Optional. If true, all returned datasets will have the latest common start date.
#' @param CommonEnd Optional. If true, all returned datasets will have the latest common end date.
#' @param CommonUA Optional. If true, the CommonStart  and ComonEnd parameters above use the user permissioned access dates as the earliest and latest dates available.
#' @param DateFormat Optional. The date format to use in the requests and results.  See the ‘Date Format Parameter‘  table below for options.
#' @param DateOrder Optional. The date order of the result rows. There are 2 options,  “asc”  for ascending (the default)  and “desc” for descending.
#' @param Prefill Optional. Fills missing values with the previous value or a calculated fill value. Prefill is calculated before the HandleWeekends parameter.
#' @param PrefillOptions Optional. Fill parameter options that affects result rows containing only null and/or only “NA” values.
#' @param Fill Optional. Identical to the Prefill option above but calculated  after the HandleWeekends parameter.
#' @param FillOptions Optional. Identical to the PrefillOptions  parameter above.
#' @param Frequency Optional. Calculate any day to year average.  See the FrequencyOptions parameter below for the available options.
#' @param FrequencyOptions Optional. Control how frequency averages are calculated.  See  the ‘Frequency Options‘ table below for details on the available settings.
#' @param Postfill Optional. Identical to the Prefill  option above but calculated  after the Frequency parameter.
#' @param PostFillOptions Optional. dentical to the PrefillOptions  parameter above.
#' @param Sparse Optional. Allows the removal of result rows that contain only null values  (“NA” rows are optional).
#' @param SparseOptions Optional. Allows the removal of result rows that contain only null values. You can also convert “NA” (no access) rows to nulls or remove only “NA” rows.
#' @param Rounding Optional. If and how to return decimal values in the result.  Rounding also affects spark values and corrections.
#' @param NAValue Optional.  Set the value to use for “NA” (no access) records.  Can be null, a number or a string.
#' @param ReturnMetadata Optional. Return in the result the full dataset metadata.  See the response ‘Metadata Object‘ table below for details.
#' @param ReturnAccess Optional. Controls if a UserAccess object is returned that contains the subscription type and the dataset access allowed.
#' @param ReturnParameters Optional. Return the request parameters and the default settings.
#' @param ReturnBateStatus Optional. 	If true, a BateStatus object is returned in the Series result parameter.
#'
#' Please click on the API help link above for the full API details.
#'
#' @examples
#' # Simple example
#'
#' Result = idata.get_dataset_values(Series  ="ECBFX/EURNZD;BateIndex=[0]")$Result
#' values = unlist(Result$Series$Values)
#' plot(x =as.Date(names(values)),as.numeric(values),xlab= "Date",ylab = "Index")
#'

idata.get_dataset_values <- function(SessionToken = NULL,
                             Series = NULL,
                             StartDate = 'Earliest',
                             EndDate = 'Latest',
                             Periods = 0,
                             CommonStart = FALSE,
                             CommonEnd = FALSE,
                             CommonUA = TRUE,
                             DateFormat = 'YYYY-MM-DD',
                             DateOrder = "asc",
                             Prefill = FALSE,
                             PrefillOptions=NULL,
                             Fill =FALSE,
                             FillOptions =NULL,
                             Frequency = 'd',
                             FrequencyOptions=NULL,
                             Postfill=FALSE,
                             PostFillOptions=NULL,
                             Sparse = FALSE,
                             SparseOptions =NULL,
                             Rounding = 'auto',
                             NAValue = NULL,
                             ReturnMetadata=FALSE,
                             ReturnAccess=FALSE,
                             ReturnParameters=TRUE,
                             ReturnBateStatus=FALSE){
  api$get_dataset_values(SessionToken = SessionToken,
                 series = Series,
                 startDate = StartDate,
                 endDate =EndDate,
                 periods = Periods,
                 commonstart = CommonStart,
                 commonend = CommonEnd,
                 commonua = CommonUA,
                 dateFormat = DateFormat,
                 postfill= Postfill,
                 postfilloptions= PostFillOptions,
                 dateOrder = DateOrder,
                 frequency = Frequency,
                 frequencyoptions=FrequencyOptions,
                 prefill = Prefill,
                 prefilloptions=PrefillOptions,
                 fill =Fill,
                 filloptions =FillOptions,
                 sparse = Sparse,
                 sparseoptions =SparseOptions,
                 rounding = Rounding,
                 navalue = NAValue,
                 returnmetadata=ReturnMetadata,
                 returnaccess=ReturnAccess,
                 returnparameters=ReturnParameters,
                 returnbatestatus=ReturnBateStatus)
}
