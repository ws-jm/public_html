#' idmmonitor: IDM Market Data API Integration in R
# here is usually a "processing function" (traditionally called zzz.R) with tasks to be performed
# when the package is loaded, such as loading libraries and compiled code.
# For example you can create a zzz.R file where you create this function:

.onLoad <- function(libname, pkgname){

  print("Checking dependendent packages...")
}
