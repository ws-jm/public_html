#' Query a session token
#' @usage idata.query_session_token(SessionToken = NULL)
#' @description
#'
#' Return the remaining time (in milliseconds) until a session token expires.
#'@details
#' For more information please visit :  \url{http://www.intdatamedia.com/api/?section=querysessiontoken}
#' @return Number in milliseconds
#' @param SessionToken Optional. Session token from the idata.get_session_token command.
#' If no token is provided then the current token will be used. You can see the current token by typing  \code{idata.print_session_token()}.
#' @examples
#' idata.query_session_token()                #use the current token
#' idata.query_session_token("CUSTOM_TOKEN")  #use a custom token
#' @export

idata.query_session_token <- function(SessionToken = NULL){
  api$query_session_token(SessionToken = SessionToken)
}
