#' Allows to change the format of the returned data
#'
#' Returned data could be raw JSON or R list
#'
#' @param raw Boolean. If FALSE (default), a list generated using jsonlite package is returned. Else
#' a JSON string is returned.
#' @examples
#' idata.set_return_raw_data(raw  = FALSE)
#' @export

idata.set_return_raw_data <- function(raw = FALSE){
  api$set_return_raw_data(raw = raw)
}
