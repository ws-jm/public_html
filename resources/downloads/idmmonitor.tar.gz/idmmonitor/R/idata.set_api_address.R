#' Set api server
#' @usage idata.set_api_server(server = NULL)
#' @description
#' This function allows to set the address for the API server. Use the 'http' or 'https' protocol prefix.
#'
#' @param server is the fill api server address with the 'https' or 'http' protocol prefix.
#' @return NULL
#' @examples
#' idata.set_api_server(server = "https://api.idatamedia.org/")
#' @export

idata.set_api_address <- function(server = NULL){
  api$set_api_address(server = server)
}
