#' idmmonitor: IDM Market Data API Integration in R
#'
#' The idmmonitor package includes functions to interact with the International Data Media  Market Data API, including
#' all available calls in the API documentation at http://www.intdatamedia.com/api.
#'
#' For a complete list of functions type \code{idata + TAB} to see all autocomplete options or write \code{library(help = "idmmonitor")} in the console
#'
#' @docType package
#' @name idmmonitor
#NULL

## NULL
## If a package is installed, it will be loaded. If any
## are not, the missing package(s) will be installed
## from CRAN and then loaded.

checking_function <- function(){
  packages = c("R6", "jsonlite", "httr")
  print("Checking packages...2")

  for(i in 1:3){
    my_package=c(packages[i])
    not_installed = my_package[!(my_package %in% installed.packages()[ , "Package"])]
    if(length(not_installed)){
      print("The required",packages[i],"is missing  and must be installed")
      print("do you want to install it now (y/n)")
      check=readline(prompt="choose your answer")
      if(check=="y" | check=="Y"){
        install.packages(not_installed)}
      else{print("The required package",packages[i]," is missing.Please install to continue")

      }



    }
  }

}

print("Checking packages...")
checking_function()


