#' Get Datasource Metadata
#'@description
#' Retrieve the metadata for the datasets in one datasource
#'@details
#'For more information please visit :  \url{https://www.idatamedia.org/api-docs#datasetsonesource}
#' @return json or list
#' @param SessionToken Optional. Session token from the idata.get_session_token command.
#' If no token is provided then the current token will be used. You can see the current token by typing  \code{idata.print_session_token()}.
#' @param Datasource The datasource ID code.
#' @param Filter Optional. A condition used to filter the returned metadata.  See the 'Filters' section in the link above.
#' @param CaseSensitive Optional. If true, filtering is case-sensitive.
#' @param SortOrder Optional. Result sort order based on SortColumns property. Values can be \code{asc} or \code{desc}  for ascending or descending.
#' @param SortColumns Optional. Column names used to sort the results.  Valid column names are:  Symbol, Datacategory  etc.
#' @param IgnoreEmpty Optional. Do not include in the result any series that contain no prices or values. Default FALSE.
#' @param ShortRecord Optional. If true, include the long description and conversion data fields in the result. Default \code{FALSE}.
#' @param CategoryFilter Optional. If the datasource is a category datasource  you can add some data category names. Please look at the help link above for details
#' @param Page Optional.The requested page from result (see rows below). Default is 1.
#' @param Rows Optional. Number of results per page. Default is 100. Maximum is 5000
#' @param ValuesSince Optional. Only return datasets that have values after this date. The default date format is \code{YYYY-MM-DD}
#' @param DateFormat Optional. The date format to use in the request and the result.  See the ‘DateFormat Parameter‘ section in the help link above for details.
#' @param ReturnAccess Optional. Returns subscription information for each dataset returned.  The result parameters Subscription, AccessStart, AccessEnd and InactiveAccess are visible only if ReturnAccess is set to true.
#'
#' @examples
#'idata.get_datasets(Datasource = "ECBFX")
#'idata.get_datasets(Datasource = "ECBFX",
#'  CaseSensitive = TRUE,
#'  Rows= 100,
#'  Page = 1,
#'  ShortRecord = FALSE,
#'  SortColumn = "Symbol,Description",
#'  Filter = "ECB -Texas")

#' @export

idata.get_datasets <- function(SessionToken = NULL,
                               Datasource = "ECBFX",
                               Filter = NULL,
                               CaseSensitive = FALSE,
                               SortOrder = 'asc',
                               SortColumns = 'Symbol',
                               IgnoreEmpty = FALSE,
                               ShortRecord = FALSE,
                               CategoryFilter = NULL,
                               Page = 1,
                               Rows = 100,
                               ValuesSince = 'Earliest',
                               DateFormat='YYYY-MM-DD',
                               ReturnAccess=FALSE){
  api$get_datasets(SessionToken = SessionToken,
                          datasource = Datasource,
                          filter = Filter,
                          caseSensitive = CaseSensitive,
                          sortOrder = SortOrder,
                          sortColumns = SortColumns,
                          ignoreEmpty = IgnoreEmpty,
                          shortRecord = ShortRecord,
                          CategoryFilter = CategoryFilter,
                          page = Page,
                          rows = Rows,
                          valuesSince = ValuesSince,
                          DateFormat = DateFormat,
                          ReturnAccess=ReturnAccess)
}
