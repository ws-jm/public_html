#' Renew a session token
#' @usage idata.renew_session_token(SessionToken = NULL)
#'@description
#' Renew a session token to full life of 30 minutes.
#'@details
#' For more information please visit :  \url{https://www.idatamedia.org/api-docs#renewsessiontoken}
#' @return NULL
#' @param SessionToken Optional. Session token from the idata.get_session_token command.
#' If no token is provided then the current token will be used. You can see the current token by typing  \code{idata.print_session_token()}.
#' @examples
#' idata.renew_session_token()                 #use the current token
#' idata.renew_session_token("CUSTOM_TOKEN")   #use a custom token
#' @export

idata.renew_session_token <- function(SessionToken = NULL){
  api$renew_session_token(SessionToken = SessionToken)
}
