#' Get Dataset Values For a Date
#'
#'@description
#' Can be used to easily create snapshot market reports showing  values, averages, change and sparkline charts.
#'@details
#'For more information please visit :  \url{https://www.idatamedia.org/api-docs#getdatasetvaluesforadate}
#' @return json or list
#' @param SessionToken Optional. Session token from the idata.get_session_token command.
#' If no token is provided then the current token will be used. You can see the current token by typing  \code{idata.print_session_token()}.
#' @param Series A list of comma separated values containing data source, category and symbol and optional additional parameters such as bateindex.  Click on the help link above for the optional parameter list.
#' Note: The category parameter is only used if the datasource is a category datasource.
#' Example: \code{ECBFX/EURGBP;Bateindex=[0],ECBFX/EURUSD}.
#' Note that elements in the list are separated by the '\code{,}' character and the data source, category and symbol values joined with a '\code{/}' character. No spaces between the elements.
#' For more information, click on the link above.
#' @param Date The request date for the returned values. Format is: “YYYY-MM-DD”.
#' @param ReturnLatest Optional.  If no is value available for the requested date then return the first valid value for an earlier date
#' @param ReturnCorrections Optional. If any corrected values are available for the requested date they can be returned in the result.
#' @param DateFormat Optional. The date format to use in the request and the result.
#' @param Rounding Optional.How to return decimal values in the result.  Rounding also affects spark values and corrections.
#' Result values are numbers and cannot contain trailing zeros.
#' @param Frequency Optional. Calculate a average from day to year.
#' @param FrequencyOptions Optional. Control how frequency averages are calculated.
#' @param SparksCount Optional. The number of previous values before the request date.
#' @param ReturnAccess Optional. If true, a UserAccess object is returned in the result Series object.
#' @param ReturnBateNames Optional. If true bate names (not bate index numbers) are returned in the values section of the result.
#' @param ReturnBateStatus Optional. Return a BateStatus object in the Series result object which returns information about the bate and its status.
#' @param ReturnMetadata Optional. Return the full dataset metadata.  See the result ‘Metadata Object‘ table for details.
#' @param ReturnParameters Optional. Return a Parameters object in the Result object containing  any request parameters (and any default settings used).
#' @examples
#' # Simple example
#'
#' idata.get_dataset_values_for_date(Series = "ECBFX/EURGBP;BateIndex=[0],ECBFX/EURUSD;BateIndex=[0]", Date = "2017-10-24")
#' idata.get_dataset_values_for_date(Series = "ECBFX/EURGBP", Date = "2017-10-24")

#' @export

 function(SessionToken = NULL,
                                  Series = NULL,
                                  Date = NULL,
                                  ReturnLatest = FALSE,
                                  ReturnCorrections = FALSE,
                                  DateFormat = 'YYYY-MM-DD',
                                  Rounding= "auto",
                                  Frequency = 'd',
                                  FrequencyOptions = NULL,
                                  SparksCount = 0,
                                  ReturnAccess= FALSE,
                                  ReturnBateNames= FALSE,
                                  ReturnBateStatus= FALSE,
                                  ReturnMetadata= FALSE,
                                  ReturnParameters= FALSE){
  api$get_dataset_values_for_date(SessionToken = SessionToken,
                      series = Series,
                      date = Date,
                      ReturnLatest = ReturnLatest,
                      ReturnCorrections = ReturnCorrections,
                      DateFormat = DateFormat,
                      Rounding = Rounding,
                      Frequency = Frequency,
                      FrequencyOptions = FrequencyOptions,
                      SparksCount = SparksCount,
                      ReturnAccess= ReturnAccess,
                      ReturnBateNames= ReturnBateNames,
                      ReturnBateStatus= ReturnBateStatus,
                      ReturnMetadata= ReturnMetadata,
                      ReturnParameters= ReturnParameters)
}
