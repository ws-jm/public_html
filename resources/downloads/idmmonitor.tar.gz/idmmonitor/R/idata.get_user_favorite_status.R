#' Get User Favorite Status
#' @usage idata.get_user_favorite_status(SessionToken = NULL)
#' @description
#' Returns the total number of ‘favorite’ series and  the date and time the user favorites file was last changed.
#' @details
#' For more information please visit :  \url{https://www.idatamedia.org/api-docs#favoritestatus}
#' @return json or list
#' @param SessionToken Optional. Session token from the idata.get_session_token command.
#' If no token is provided then the current token will be used. You can see the current token by typing  \code{idata.print_session_token()}.
#' @examples
#' idata.get_user_favorite_status()
#' @export

idata.get_user_favorite_status <- function(SessionToken = NULL){
  api$get_user_favorite_status(SessionToken = SessionToken)
}
