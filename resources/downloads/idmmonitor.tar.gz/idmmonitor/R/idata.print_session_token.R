#' Print the current session token
#'
#'
#' @return Session token
#' @examples
#' idata.print_session_token()
#' @export

idata.print_session_token <- function(){
  api$SessionToken
}
