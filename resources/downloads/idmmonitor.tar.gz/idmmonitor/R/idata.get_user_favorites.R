#' Get User Favorites
#'@description
#' Get the metadata for your favorite datasets (your collection of datasets from multiple datasources).
#'@details
#'For more information please visit :  \url{https://www.idatamedia.org/api-docs#favoritesmetadata}
#' @return json or list
#' @param SessionToken Optional. Session token from the idata.get_session_token command.
#' If no token is provided then the current token will be used. You can see the current token by typing  \code{idata.print_session_token()}.
#' @param IgnoreEmpty If true and a series has no values, it is not included in the result
#' @param ReturnFavoritesTree Optional. If true, a UserAccess object with  information on each dataset is returned in the dataset object.  If the result dataset parameter Subscription is “None”, the UserAccess object is not returned as no subscription exists.
#' @param ReturnAccess Optional.Returns which datasources and data categories that the user can/cannot access.   This controls if the result  parameters  'Subscription', 'UserCategoryCount' and 'UserAccess' are returned in the datasets.
#' @param Page Optional. The page number to select (see 'rows' and 'note' in the link above)
#' @param Rows Optional. Number of rows per page.  Default is 50. Maximum is 500
#' @param DateFormat Optional. The date format to use in the request and the result.  See the ‘DateFormat Parameter‘ section the link above for details.
#'
#' @examples
#' idata.get_user_favorites()
#' @export

idata.get_user_favorites <- function(SessionToken = NULL,
                                     IgnoreEmpty=FALSE,
                                     ReturnFavoritesTree=FALSE,
                                     ReturnAccess=FALSE,
                                     Page=1,
                                     Rows=50,
                                     DateFormat='YYYY-MM-DD'){
  api$get_user_favorites(SessionToken = SessionToken,
                         IgnoreEmpty=IgnoreEmpty,
                         ReturnFavoritesTree=ReturnFavoritesTree,
                         ReturnAccess=ReturnAccess,
                         Page=Page,
                         Rows=Rows,
                         DateFormat=DateFormat)
}
