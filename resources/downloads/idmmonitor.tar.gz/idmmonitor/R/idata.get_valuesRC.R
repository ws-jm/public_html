#' Get Dataset Values RC
#'
#'@description
#' Get datasets in one or more datasource, formatted in a row by column layout.
#'@details
#'For more information please visit :  \url{https://www.idatamedia.org/api-docs#getdatasetvaluesrc}
#' @return json or list
#' @param SessionToken Optional. Session token from the idata.get_session_token command.
#' If no token is provided then the current token will be used. You can see the current token by typing  \code{idata.print_session_token()}.
#' @param Series A list of comma separated values containing data source, category and symbol and optional additional parameters such as Bateindex.  Click on the help link above for the optional parameter list.
#' Note: The category parameter is only used if the datasource is a category datasource.
#' Example: \code{ECBFX/EURGBP;Bateindex=[0],ECBFX/EURUSD}.
#' Note that elements in the list are separated by the '\code{,}' character and the data source, category and symbol values joined with a '\code{/}' character. No spaces between the elements.
#' For more information, click on the link above.
#' @param StartDate Optional. The earliest date to return. ‘Earliest’ means use first available.   Format is: “YYYY-MM-DD”.
#' @param EndDate Optional.  The latest Date to return. ‘Latest’ means  use last available.  Format is: “YYYY-MM-DD”.
#' @param common_start Clip result so all  series have the same start date.
#' @param Periods Optional. Can be used  instead of the StartDate/EndDate parameters to return the most recent number of values in the selected frequency.
#' @param ClipStart Optional. Select if all returned datasets have the a common start date (with a value).
#' @param ClipEnd Optional. Select if all returned datasets have the same common end date (with a value).
#' @param DateFormat Optional. The date format to use in the requests and results.  See the ‘Date Format Parameter‘  table below for options.
#' @param DateOrder Optional. The date order of the result rows. There are 2 options,  “asc”  for ascending (the default)  and “desc” for descending.
#' @param Prefill Optional. Fills missing values with the previous value or a calculated fill value. Prefill is calculated before the HandleWeekends parameter.
#' @param PrefillOptions Optional. Fill parameter options that affects result rows containing only null and/or only “NA” values.
#' @param Fill Optional. Identical to the Prefill option above but calculated  after the HandleWeekends parameter.
#' @param FillOptions Optional. Identical to the PrefillOptions  parameter above.
#' @param Frequency Optional. Calculate any day to year average.  See the FrequencyOptions parameter below for the available options.
#' @param FrequencyOptions Optional. Control how frequency averages are calculated.  See  the ‘Frequency Options‘ table below for details on the available settings.
#' @param Postfill Optional. Identical to the Prefill  option above but calculated  after the Frequency parameter.
#' @param PostFillOptions Optional. dentical to the PrefillOptions  parameter above.
#' @param Sparse Optional. Allows the removal of result rows that contain only null values  (“NA” rows are optional).
#' @param SparseOptions Optional. Allows the removal of result rows that contain only null values. You can also convert “NA” (no access) rows to nulls or remove only “NA” rows.
#' @param Rounding Optional. If and how to return decimal values in the result.  Rounding also affects spark values and corrections.
#' @param ReturnMetadata Optional. Return in the result the full dataset metadata.  See the response ‘Metadata Object‘ table below for details.
#' @param ReturnAccess Optional. Controls if a UserAccess object is returned that contains the subscription type and the dataset access allowed.
#' @param ReturnParameters Optional. Return the request parameters and the default settings.
#' @examples
#' # Simple example
#'
#' Result = idata.get_dataset_valuesRC(Series  ="ECBFX/EURNZD")$Result
#' values = unlist(Result$Rows)
#' plot(x =as.Date(names(values)),as.numeric(values),xlab= "Date",ylab = "Index")
#' @export
idata.get_dataset_valuesRC <-  function(SessionToken = NULL,
                                        Series = NULL,
                                        StartDate = 'Earliest',
                                        EndDate = 'Latest',
                                        Periods = 0,
                                        ClipStart = FALSE,
                                        ClipEnd = FALSE,
                                        DateFormat = 'YYYY-MM-DD',
                                        DateOrder = "asc",
                                        Prefill = FALSE,
                                        PrefillOptions=NULL,
                                        Fill =FALSE,
                                        FillOptions =NULL,
                                        Frequency = 'd',
                                        FrequencyOptions=NULL,
                                        Postfill=FALSE,
                                        PostFillOptions=NULL,
                                        Sparse = FALSE,
                                        SparseOptions =NULL,
                                        Rounding = 'auto',
                                        ReturnMetadata=FALSE,
                                        ReturnAccess=FALSE,
                                        ReturnParameters=TRUE){
  api$get_dataset_valuesRC(SessionToken = SessionToken,
                         series = Series,
                         startDate = StartDate,
                         endDate =EndDate,
                         periods = Periods,
                         clipstart = ClipStart,
                         clipend = ClipEnd,
                         dateFormat = DateFormat,
                         postfill= Postfill,
                         postfilloptions= PostFillOptions,
                         dateOrder = DateOrder,
                         frequency = Frequency,
                         frequencyoptions=FrequencyOptions,
                         prefill = Prefill,
                         prefilloptions=PrefillOptions,
                         fill =Fill,
                         filloptions =FillOptions,
                         sparse = Sparse,
                         sparseoptions =SparseOptions,
                         rounding = Rounding,
                         returnmetadata=ReturnMetadata,
                         returnaccess=ReturnAccess,
                         returnparameters=ReturnParameters)
}
