#' Set api key
#'@usage idata.set_api_key(APIKey = NULL)
#'@description
#' This function allows to set your api key
#'
#' @param APIKey  Personal API key  that is required to access the API
#' @return NULL
#' @examples
#' idata.set_api_key(APIKey = "YOUR_API_KEY")
#' @export

idata.set_api_key <- function(APIKey = NULL){
  api$set_api_key(APIKey = APIKey)
}
