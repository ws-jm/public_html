#' Get session token
#' @description
#' This function returns a session token that is needed to access the Monitor+ API.
#' You must set your API key using the idata.set_api_key command before using this call.
#' @details
#' For more information please visit :  \url{https://www.idatamedia.org/api-docs#sessiontoken}
#'
#' @return NULL
#' @examples
#' idata.get_session_token()
#' @export

idata.get_session_token <- function(){
  api$get_session_token()
}
