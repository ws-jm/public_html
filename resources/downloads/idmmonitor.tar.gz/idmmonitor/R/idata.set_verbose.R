#' Allows to set the verbose global parameter to echo command information.
#'
#' @param verbose logical. If TRUE extra the request details are displayed in the console. Default: FALSE
#' @examples
#' idata.set_verbose(TRUE)
#' @export

idata.set_verbose <- function(verbose = FALSE){
  api$set_verbose(verbose = verbose)
}
