#' Get Dataset Values RC
#'
#' Use your session token to retrieve market data from datasets in one or more datasource, formatted for easy application display in a row by column layout.
#'
#' @return json or list
#' @param token Optional. Session token from the GetSessionToken endpoint. You can provide a custom token.
#' If no token is provided then the current token (you can see it typing
#' \code{idata.print_session_token()}) will be used.
#' @param series Collection of data source, category and symbol codes  with optional parameters.
#' Example: \code{ECBFX/EURGBP,ECBFX/EURUSD}. Note that
#' elements in the list are separated by \code{,}.
#' @param start_date The earliest date to return. ‘Earliest’ means use first available.   Format is: “YYYY-MM-DD”.
#' @param end_date  The latest Date to return. ‘Latest’ means  use last available.  Format is: “YYYY-MM-DD”.
#' @param common_start Clip result so all  series have the same start date.
#' @param common_end Clip result so all  series have the same end date.
#' @param date_format The date format to use in the result.
#' @param prefill Fill missing values with the most recent prior value. Calculated before HandleWeekends and Frequency.
#' @param handle_weekends  Decide if and how weekends are handled in the source data. See  the HandleWeekends
#'  table in API documentation website.
#' @param frequency Calculate a day to year average.  See the Frequency table in API documentation website.
#' @param fill Fill missing values with the most recent prior value. Calculated after  Frequency.
#' @param sparse  Option to remove some or all rows containing only null values. See the Sparse table in API documentation website.
#' @param use_period_start_date Use the first or last date of the calculated frequency in the result.  If true, the first date is returned.
#' @param frequency_start_day  For custom frequencies only. For custom week it can be 1-7 (1 is Monday).  For custom month  it is the
#'  first day of the month to be used. For custom half-month  it is the first day of the first period in the calculation. Range  is 1-31.
#' @param frequency_end_day For custom month and half-month only. For custom month it defines the last day of the month to use and for
#'  custom half-month  it is the last day of the first period to use.  Range is 1-31. The default is 31 for custom month or 15 for custom half month.
#' @param frequency_start_day2  For custom half-month only. It is the first day of the second period of the calculation.  Range is 1-31.  Default is 16.
#' @param frequency_end_day2 For custom half-month only. It is the last day of the second period in the calculation.  Range is 1-31.  Default is 31.
#' @param weekends_in_avg_result For custom half-month only. It is the last day of the second period in the calculation.  Range is 1-31.  Default is 31.
#' @param rounding If and how to round decimals in the result. See the Rounding  table in API documentation website.
#' @param clip_interval Sets the StartDate/EndDate to the actual earliest/latest available values for the selected  series range.
#' @examples
#' idata.get_dataset_values_rc(series = 'ECBFX/EURGBP,ECBFX/EURUSD')
#' @export

idata.get_dataset_values_rc <- function(token = NULL,
                                     series = NULL,
                                     start_date = 'Earliest',
                                     end_date = 'Latest',
                                     common_start = FALSE,
                                     common_end = FALSE,
                                     date_format = 'YYYY-MM-DD',
                                     prefill = FALSE,
                                     handle_weekends = 'def',
                                     frequency = 'd',
                                     fill = FALSE,
                                     sparse = 'on',
                                     use_period_start_date = FALSE,
                                     frequency_start_day = 1,
                                     frequency_end_day = 31,
                                     frequency_start_day2 = 16,
                                     frequency_end_day2 = 31,
                                     weekends_in_avg_result = 'def',
                                     rounding = 'def',
                                     clip_interval = TRUE){
  api$get_dataset_values(token = token,
                         series = series,
                         startDate = start_date,
                         endDate = end_date,
                         commonStart = common_start,
                         commonEnd = common_end,
                         dateFormat = date_format,
                         prefill = prefill,
                         handleWeekends = handle_weekends,
                         frequency = frequency,
                         fill =fill,
                         sparse = sparse,
                         usePeriodStartDate = use_period_start_date,
                         frequencyStartDay = frequency_start_day,
                         frequencyEndDay = frequency_end_day,
                         frequencyStartDay2 = frequency_start_day2,
                         frequencyEndDay2 = frequency_end_day2,
                         weekendsinAvgResult = weekends_in_avg_result,
                         rounding = rounding,
                         clipInterval = clip_interval,
                         rc = TRUE)
}
