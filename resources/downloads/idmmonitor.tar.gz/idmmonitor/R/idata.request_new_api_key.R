#' Request API Key
#'@description
#' Returns a new API key from the server using the current session token.
#'@details
#'For more information please visit :  \url{https://www.idatamedia.org/api-docs#return-new-api-key}
#' @return json or list
#' @param SessionToken Optional. Session token from the GetSessionToken endpoint is used.)
#' @examples
#' idata.request_new_api_key()
#' @export
idata.request_new_api_key <- function(SessionToken = NULL){
  api$request_new_api_key(SessionToken = SessionToken)
}
