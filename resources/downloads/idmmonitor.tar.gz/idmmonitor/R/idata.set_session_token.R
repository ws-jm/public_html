#' Set session token
#'
#' OBSOLETE - do not use. This function allows to set a new session token
#'
#' @param token Session token from the GetSessionToken endpoint.
#' @return NULL
#' @examples
#' idata.set_session_token(token = "session_token")
#' @export

idata.set_session_token <- function(token = NULL){
  api$set_session_token(token = token)
}
