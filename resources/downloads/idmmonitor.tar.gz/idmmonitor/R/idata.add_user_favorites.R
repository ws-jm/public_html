#' Add Datasets To Favorites
#'@description
#' Add one or more datasets to your favorites list.
#'@details
#'For more information please visit :  \url{https://www.idatamedia.org/api-docs#adddatasetstofavorites}
#' @return json or list
#' @param SessionToken Optional. Session token from the idata.get_session_token command.
#' If no token is provided then the current token will be used. You can see the current token by typing  \code{idata.print_session_token()}.
#' @param Series Collection of comma separated data source/category/symbols (category is only needed for "category" datasources).
#' Example: \code{ECBFX/EURGBP,ECBFX/EURUSD}.
#' Note that elements in the list are separated by a comma: ' \code{,}'.
#' @examples
#' idata.add_user_favorites(Series = 'ECBFX/EURGBP')
#' @export

idata.add_user_favorites <- function(SessionToken = NULL,
                                              Series = "ECBFX/EURGBP"){
  api$add_user_favorites(SessionToken = SessionToken,
                                 series = Series)
}
