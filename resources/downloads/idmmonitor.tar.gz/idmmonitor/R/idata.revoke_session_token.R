#' Revoke a session token
#'@usage idata.revoke_session_token(SessionToken = NULL)
#'@description
#'  Revoke (delete) a session token. This endpoint can be called when you have finished
#'  your API session and wish to delete your session token so that it cannot be reused.
#'@details
#'  For more information please visit :  \url{https://www.idatamedia.org/api-docs#revokesessiontoken}
#'
#' @return NULL
#' @param SessionToken Optional. Session token from the idata.get_session_token command.
#' If no token is provided then the current token will be used. You can see the current token by typing  \code{idata.print_session_token()}.
#' @examples
#' idata.revoke_session_token()                #use the current token
#' idata.revoke_session_token("CUSTOM_TOKEN")  #use a custom token
#' @export

idata.revoke_session_token <- function(SessionToken = NULL){
  api$revoke_session_token(SessionToken = SessionToken)
}
