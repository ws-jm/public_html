#' Get Datasets Metadata
#'@description
#' Get the metadata for the dataset(s) specified in the request.
#' Datasets can be from multiple datasources.

#'@details
#'For more information please visit :  \url{https://www.idatamedia.org/api-docs#datasetsmultiplesources}
#' @return json or list
#' @param SessionToken Optional. Session token from the idata.get_session_token command.
#' If no token is provided then the current token will be used. You can see the current token by typing  \code{idata.print_session_token()}.
#' @param Series A CSV list of  of data source/category/symbols. Example: \code{ECBFX/EURGBP,ECBFX/EURUSD}. The category  parameter is required if the datasource is a Category datasource
#'  e.g:  { Series= “ECBFX/GBPUS, ECBFX/EURJPY” }
#' @param ShortRecord  Optional. If true, the result will not include additional data, conversion fields and the default settings for returning  the CategoryTree, CategoryList  and  UserCategoryList are set to false.
#' @param ValuesSince  Optional. Only return datasets that have values after this date. The default date format is “YYYY-MM-DD” format. Enter the date or use the word “Earliest”. If you ignore the parameter the earliest date will be returned.
#' @param ReturnAccess Optional. 	Returns subscription information for each dataset returned.  The result parameters Subscription, AccessStart, AccessEnd and InactiveAccess are visible only if ReturnAccess is set to true.
#' @param  DateFormat Optional. The date format to use in the request and the result.  See the ‘DateFormat Parameter‘ section in the link above for details.
#' @examples
#' idata.get_selected_datasets(Series = "ECBFX/EURGBP,ECBFX/EURUSD")
#' @export

idata.get_selected_datasets <- function(SessionToken = NULL,
                                        Series = NULL,
                                        ShortRecord=FALSE,
                                        ValuesSince="Earliest",
                                        ReturnAccess= "FALSE",
                                        DateFormat='YYYY-MM-DD'){
  api$get_selected_datasets(SessionToken = SessionToken,
                            Series = Series,
                            ShortRecord=ShortRecord,
                            ValuesSince=ValuesSince,
                            ReturnAccess= ReturnAccess,
                            DateFormat = DateFormat)
}
