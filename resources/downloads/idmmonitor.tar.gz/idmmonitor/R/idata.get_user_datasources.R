#' Get User Datasources
#'@description
#' Return a detailed list of all datasources that are available with the current subscription.
#'@details
#' For more information please visit :  \url{https://www.idatamedia.org/api-docs#userdatasource}
#' @return json or list
#' @param SessionToken Optional. Session token from the idata.get_session_token command.
#' If no token is provided then the current token will be used. You can see the current token by typing  \code{idata.print_session_token()}.
#' @param ReturnCategoryList Optional. Default TRUE Returns detailed category information but only if the datasource is a categoryDS datasource.
#' @param ReturnCategoryTree Optional. Default TRUE If true, returns a hierarchical data tree  of the data categories (if available). The tree is used to organise and present the datasets in logical groups.
#'  See the Details and DetailsDS tables in the link above for details.
#' @param ReturnUserCategoryList Optional. Default FALSE, For CategoryDS datasources only. It returns in the DetailsDS object a list of data categories and date ranges that the user can access.
#' @param ReturnAccess Optional. Default FALSE. Returns details of the datasources (and data categories) that the user can access
#' @param DateFormat Optional. Default "YYYY-MM-DD". The date format to use in the request and the result.  See the ‘DateFormat Parameter‘ section in the link above for details.
#' @examples
#' idata.get_user_datasources()                         #use the current token
#' idata.get_user_datasources(ReturnCategoryTree = FALSE) #use the current token and do not return any category tree in the result
#' idata.get_all_datasources()$Result$Name          # get all Datasource names only. Use $Datasource  to get the datasource codes.
#' @export

idata.get_user_datasources <- function(SessionToken = NULL,ReturnCategoryList = TRUE,ReturnCategoryTree=TRUE,ReturnUserCategoryList=FALSE,ReturnAccess=FALSE,DateFormat='YYYY-MM-DD'){
  api$get_user_datasources(SessionToken = SessionToken,
                           ReturnCategoryList = ReturnCategoryList,
                           ReturnCategoryTree=ReturnCategoryTree,
                           ReturnUserCategoryList=ReturnUserCategoryList,
                           ReturnAccess=ReturnAccess,
                           DateFormat=DateFormat)
}


