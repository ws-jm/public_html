#' Print the current api key
#'
#'@description
#' Displays the current API key that was set with the command idata.set_api_key().
#'
#' @return api key
#' @examples
#' idata.print_api_key()
#' @export
#'

idata.print_api_key <- function(){
  api$APIKey
#==   api$api_key
}
